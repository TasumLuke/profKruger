// Variables to hold the table and its body
const table = document.getElementById('code-table');
const tbody = table.getElementsByTagName('tbody')[0];

// Function to parse assembly code into table rows
function parseCode(code) {
  // Clear the table body
  tbody.innerHTML = '';

  // Split the code into lines
  const lines = code.trim().split('\n');

  // Create a table row for each line
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Split the line into address, opcode, and operand
    const [address, opcode, operand] = line.split(/\s+/);

    // Create a table row with the address, opcode, and operand in separate cells
    const tr = document.createElement('tr');
    const tdAddress = document.createElement('td');
    const tdOpcode = document.createElement('td');
    const tdOperand = document.createElement('td');
    tdAddress.textContent = address;
    tdAddress.classList.add('address');
    tdOpcode.textContent = opcode;
    tdOpcode.classList.add('opcode');
    tdOperand.textContent = operand;
    tdOperand.classList.add('operand');
    tr.appendChild(tdAddress);
    tr.appendChild(tdOpcode);
    tr.appendChild(tdOperand);

    // Add the row to the table body
    tbody.appendChild(tr);
  }
}

// Function to handle user input
function handleInput(event) {
  const fileInput = document.getElementById('file-input');
  const codeInput = document.getElementById('code-input');

  // If the user clicks the "Load File" button, read the contents of the file
  if (event.target.id === 'load-file') {
    const file = fileInput.files[0];
    const reader = new FileReader();
    reader.onload = function() {
      parseCode(reader.result);
    }
    reader.readAsText(file);
  }

  // If the user types or pastes code into the textarea, parse it immediately
  if (event.target.id === 'code-input') {
    const code = codeInput.value;
    parseCode(code);
  }
}

// Add event listeners to the file input, code input, and "Load File" button
const fileInput = document.getElementById('file-input');
fileInput.addEventListener('change', handleInput);
const codeInput = document.getElementById('code-input');
codeInput.addEventListener('input', handleInput);
const loadButton = document.getElementById('load-file');
loadButton.addEventListener('click', handleInput);