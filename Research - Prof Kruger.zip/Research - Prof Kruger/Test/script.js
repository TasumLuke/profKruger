function createGrid() {
    // Get the input from the textarea
    const input = document.getElementById('input').value;
    
    // Check if the input is empty
    if (!input.trim()) {
      document.getElementById('grid').innerHTML = '';
      document.getElementById('error').innerHTML = '<p class="error">Error: Input is empty.</p>';
      return;
    }
    
    // Split the input by new line character
    const lines = input.split('\n');
    
    // Create the table element
    const table = document.createElement('table');
    
    // Create the tbody element
    const tbody = document.createElement('tbody');
    
    // Iterate through the lines array
    for (const line of lines) {
      // Create the tr element
      const tr = document.createElement('tr');
      
      // Split the line by space character
      const tokens = line.split(' ');
      
      // Iterate through the tokens array
      for (const token of tokens) {
        // Create the td element
        const td = document.createElement('td');
        
        // Set the text content of the td element to the token
        td.textContent = token;
        
        // Add the td element to the tr element
        tr.appendChild(td);
      }
      
      // Add the tr element to the tbody element
      tbody.appendChild(tr);
    }
    
    // Add the tbody element to the table element
    table.appendChild(tbody);
    
    // Clear the grid and error messages
    document.getElementById('grid').innerHTML = '';
    document.getElementById('error').innerHTML = '';
    
    // Add the table element to the grid div
    document.getElementById('grid').appendChild(table);
  }
  
  function loadFile() {
    const file = document.getElementById('file').files[0];
    
    if (!file) {
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
      document.getElementById('input').value = e.target.result;
    };
    
    reader.readAsText(file);
  }
  