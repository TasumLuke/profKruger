// Wait for the page to load before adding event listeners
document.addEventListener('DOMContentLoaded', function() {
  // Get the form and code grid elements
  var form = document.querySelector('#submit-form');
  var codeGrid = document.querySelector('#code-grid');

  // When the form is submitted, send the assembly code to the server
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    var code = document.querySelector('#assembly-code').value;
    sendAssemblyCode(code);
  });

  // Function to send the assembly code to the server using AJAX
  function sendAssemblyCode(code) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          // If the code was successfully submitted, update the code grid
          var response = JSON.parse(xhr.responseText);
          updateCodeGrid(response.codeGrid);
        } else {
          alert('Error: ' + xhr.statusText);
        }
      }
    };
    xhr.open('POST', '/submit-code', true);
    xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
    xhr.send(JSON.stringify({code: code}));
  }

  // Function to update the code grid on the index page
  function updateCodeGrid(codeGrid) {
    codeGrid.forEach(function(row, rowIndex) {
      row.forEach(function(opcode, colIndex) {
        var cell = codeGrid[rowIndex][colIndex];
        var cellElement = codeGrid[rowIndex][colIndex] = document.createElement('div');
        cellElement.classList.add('cell');
        cellElement.textContent = opcode;
        codeGrid.replaceChild(cellElement, cell);
      });
    });
  }
});