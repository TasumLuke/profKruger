// Selecting the input element and assign to variable
const inputElement = document.getElementById("file-input");

// Adding an event listener to the input element
inputElement.addEventListener("change", handleFiles, false);

// Function to handle file upload
function handleFiles() {
  const fileList = this.files; // FileList object
  const reader = new FileReader();

  // Set up the onload event before reading the file
  reader.onload = function(event) {
    const text = event.target.result;
    document.getElementById("input-text").innerHTML = text;
  };

  // Read the selected file as text
  reader.readAsText(fileList[0]);
}

// Color codes for Assembly Language
const asmCodeColors = [
  "blue", // registers
  "green", // comments
  "purple", // labels
  "red", // operators
];

// Selecting the input element and assign to variable
const asmInput = document.getElementById("asm-input");

// Adding an event listener to the input element
asmInput.addEventListener("input", highlightAsmCode);

// Function to highlight Assembly code
function highlightAsmCode() {
  const asmCode = asmInput.value;
  let highlightedCode = asmCode;

  // Apply color codes for each type of text
  asmCodeColors.forEach((color, index) => {
    const regex = getRegexForType(index);
    highlightedCode = highlightedCode.replace(
      regex,
      `<span style="color:${color}">$&</span>`
    );
  });

  // Update the HTML with the highlighted code
  document.getElementById("asm-output").innerHTML = highlightedCode;
}

// Function to get regex for each type of Assembly text
function getRegexForType(type) {
  switch (type) {
    case 0: // registers
      return /r\d+/g;
    case 1: // comments
      return /\/\/.*/g;
    case 2: // labels
      return /\w+:$/g;
    case 3: // operators
      return /\b(add|sub|mul|div)\b/g;
    default:
      return /()/g; // empty regex
  }
}
