// Define the opcode table for x86 assembly
const opcodeTable = {
  mov: { size: 2, opcode: 'B8' },
  add: { size: 1, opcode: '00' },
  sub: { size: 1, opcode: '28' },
  mul: { size: 1, opcode: 'F7', functionCode: '04' },
  div: { size: 1, opcode: 'F7', functionCode: '06' },
};

// Define the function to validate an opcode
function isValidOpcode(opcode) {
  return Object.keys(opcodeTable).includes(opcode);
}

// Define the function to validate an operand
function isValidOperand(operand) {
  // Check if the operand is a valid register
  const validRegisters = ['eax', 'ebx', 'ecx', 'edx', 'esi', 'edi'];
  if (validRegisters.includes(operand)) {
    return true;
  }

  // Check if the operand is a valid immediate value
  if (/^(-?\d+)$/.test(operand)) {
    const value = parseInt(operand);
    return value >= -2147483648 && value <= 4294967295;
  }

  // If the operand is not a register or immediate value, it is invalid
  return false;
}

// Define the function to parse a single line of assembly code
function parseLine(line) {
  // Remove leading/trailing white space and comments
  const trimmedLine = line.trim().split(/[@#;]/)[0];

  // Skip empty lines or comments
  if (trimmedLine.length === 0) {
    return null;
  }

  // Split the line into parts
  const parts = trimmedLine.split(/\s+/);

  // Get the address of the instruction
  const address = parts.shift();

  // Get the opcode of the instruction
  const opcode = parts.shift();

  // Check if the opcode is valid
  if (!isValidOpcode(opcode)) {
    throw new Error(`Invalid opcode: ${opcode}`);
  }

  // Get the operands of the instruction
  const operands = parts.join(' ').split(',');

  // Check if the operands are valid
  if (operands.some((operand) => !isValidOperand(operand.trim()))) {
    throw new Error(`Invalid operand: ${line}`);
  }

  // Encode the instruction
  const { size, opcode: opcodeValue, functionCode } = opcodeTable[opcode];
  let encodedInstruction = opcodeValue;

  if (size > 1) {
    // Add the function code if the opcode has size > 1
    encodedInstruction += functionCode;
  }

  // Add the operands to the encoded instruction
  operands.forEach((operand) => {
    const trimmedOperand = operand.trim();

    if (validRegisters.includes(trimmedOperand)) {
      // If the operand is a register, encode the register number
      const registerNumber = validRegisters.indexOf(trimmedOperand);
      encodedInstruction += (registerNumber + 8).toString(16).toUpperCase();
    } else {
      // If the operand is an immediate value, encode the value in little-endian format
      const value = parseInt(trimmedOperand);
      const hexValue = value.toString(16).padStart(size * 2, '0');
      const littleEndianValue = hexValue.match(/.{2}/g).reverse().join('');
      encodedInstruction += littleEndianValue.toUpperCase();
    }
  });

  // Return the encoded instruction and address
  return { address, encodedInstruction };
}

// Define the function to highlight the input code
function highlightCode(input) {
  const keywords = ['mov', 'add', 'sub', 'mul', 'div', 'jmp', 'je', 'jne', 'cmp', 'push', 'pop'];
  const registers = ['eax', 'ebx', 'ecx', 'edx', 'ebp', 'esp', 'eip'];
  const operands = ['BYTE PTR', 'WORD PTR', 'DWORD PTR'];
  const comments = [';', '#', '//', '@'];
  const regex = new RegExp(`\\b(${keywords.concat(registers).concat(operands).join('|')})\\b`, 'g');
  const regexComments = new RegExp(`(${comments.join('|')}).*$`, 'g');
  const result = input.replace(regex, '<span class="keyword">$&</span>');
  return result.replace(regexComments, '<span class="comment">$&</span>');
}

// Define the function to check if an opcode is valid
function isValidOpcode(opcode) {
  const opcodeTable = {
    mov: ['r/m32', 'r32', 'm32', 'imm32'],
    add: ['r/m32', 'r32', 'm32', 'imm32'],
    sub: ['r/m32', 'r32', 'm32', 'imm32'],
    mul: ['r/m32'],
    div: ['r/m32'],
    jmp: ['rel32'],
    je: ['rel32'],
    jne: ['rel32'],
    cmp: ['r/m32', 'r32', 'm32', 'imm32'],
    push: ['r32', 'm32'],
    pop: ['r32', 'm32'],
  };
  return opcode in opcodeTable;
}

// Define the function to parse each line of the assembly code
function parseLine(line) {
  const tokens = line.trim().split(/\s+/);
  const opcode = tokens[0];
  if (!isValidOpcode(opcode)) {
    throw new Error(`Invalid opcode: ${opcode}`);
  }
  const operands = tokens.slice(1);
  const expectedOperands = opcodeTable[opcode];
  if (operands.length !== expectedOperands.length) {
    throw new Error(`Expected ${expectedOperands.length} operands, but got ${operands.length}`);
  }
  for (let i = 0; i < operands.length; i++) {
    const operand = operands[i];
    if (expectedOperands[i] === 'r32' && !operand.startsWith('r')) {
      throw new Error(`Invalid operand: ${operand}`);
    }
    if (expectedOperands[i] === 'm32' && !operand.startsWith('[')) {
      throw new Error(`Invalid operand: ${operand}`);
    }
    if (expectedOperands[i] === 'imm32' && !/^\d+$/.test(operand)) {
      throw new Error(`Invalid operand: ${operand}`);
    }
  }
  return [opcode, ...operands];
}

// Define the function to parse the entire assembly code
function parse(code) {
  const lines = code.trim().split('\n');
  const instructions = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.trim() === '' || line.trim().startsWith(';') || line.trim().startsWith('#') || line.trim().startsWith('//') || line.trim().startsWith('@')) {
      continue;
    }
    const instruction = parseLine(line);
    instructions.push(instruction);
  }
  return instructions;
}

// Define the compile function
function compile() {
    // Get the input assembly code
    const input = inputElement.value.trim();
  
    // Parse the input into instructions
    const instructions = parse(input);
  
    // Encode the instructions into machine code
    const machineCode = encode(instructions);
  
    // Highlight the input assembly code
    const highlightedCode = highlightCode(input);
  
    // Display the machine code and highlighted input code
    outputElement.innerHTML = `<h2>Machine Code:</h2><pre>${machineCode}</pre><h2>Highlighted Code:</h2><pre>${highlightedCode}</pre>`;
  
    // Parse the instructions into a table
    const table = parseInstructionsToTable(instructions);
  
    // Display the table
    outputElement.innerHTML += `<h2>Table:</h2>${table}`;
  }

// Define the function to generate the table from
function generateTable(parsedCode) {
  let table = document.createElement('table');
  table.classList.add('assembly-table');

  // Create the table header
  let headerRow = table.insertRow();
  let headerLabels = ['Address', 'Opcode', 'Operand', 'Comment'];
  for (let label of headerLabels) {
    let th = document.createElement('th');
    th.textContent = label;
    headerRow.appendChild(th);
  }

  // Add the rows to the table
  for (let i = 0; i < parsedCode.length; i++) {
    let row = table.insertRow();
    row.classList.add('assembly-row');

    let addressCell = row.insertCell();
    addressCell.classList.add('address-cell');
    addressCell.textContent = parsedCode[i].address;

    let opcodeCell = row.insertCell();
    opcodeCell.classList.add('opcode-cell');
    opcodeCell.textContent = parsedCode[i].opcode;

    let operandCell = row.insertCell();
    operandCell.classList.add('operand-cell');
    operandCell.textContent = parsedCode[i].operand;

    let commentCell = row.insertCell();
    commentCell.classList.add('comment-cell');
    commentCell.textContent = parsedCode[i].comment;
  }

  return table;
}