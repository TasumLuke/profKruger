// DOM Elements
const inputFile = document.getElementById('input-file');
const loadButton = document.getElementById('load-button');
const codeTable = document.getElementById('code-table');

// Load file on button click
loadButton.addEventListener('click', () => {
	inputFile.click();
});

function convertToTable() {
    // Get the assembly code from the textarea
    const assemblyCode = document.getElementById("assembly-code").value;

    // Split the code into individual lines
    const codeLines = assemblyCode.trim().split("\n");

    // Create a table element and a header row
    const table = document.createElement("table");
    const headerRow = document.createElement("tr");
    table.appendChild(headerRow);

    // Add the column headers to the header row
    const headers = ["Address", "Code"];
    for (const header of headers) {
      const th = document.createElement("th");
      th.textContent = header;
      headerRow.appendChild(th);
    }

    // Add a row to the table for each line of code
    for (let i = 0; i < codeLines.length; i++) {
      const codeLine = codeLines[i];
      const tr = document.createElement("tr");

      // Add the address column to the row
      const addressTd = document.createElement("td");
      addressTd.textContent = i.toString();
      tr.appendChild(addressTd);

      // Add the code column to the row
      const codeTd = document.createElement("td");
      codeTd.textContent = codeLine;
      tr.appendChild(codeTd);

      // Add the row to the table
      table.appendChild(tr);
    }

    // Add the table to the page
    const tableContainer = document.getElementById("table-container");
    tableContainer.innerHTML = "";
    tableContainer.appendChild(table);
  }

  const codeEditor = document.getElementById("assembly-code");

  // Change color of textarea on input
  codeEditor.addEventListener("input", () => {
    const code = codeEditor.value;
    const keywords = ["mov", "add", "sub", "jmp", "call", "ret", "cmp", "jne", "je", "jl", "jle", "jg", "jge"];
    const keywordColors = ["#f8d49d", "#f7b2a5", "#f7b2a5", "#c7e9c0", "#c7e9c0", "#c7e9c0", "#f8d49d", "#9ac9ff", "#9ac9ff", "#9ac9ff", "#9ac9ff", "#9ac9ff", "#9ac9ff"];
    let formattedCode = "";

    const codeLines = code.trim().split("\n");
    for (const line of codeLines) {
      let formattedLine = line;
      for (let i = 0; i < keywords.length; i++) {
        const keyword = keywords[i];
        const keywordColor = keywordColors[i];
        const regex = new RegExp("\\b" + keyword + "\\b", "gi");
        formattedLine = formattedLine.replace(regex, `<span style="color: ${keywordColor};">${keyword}</span>`);
      }
      formattedCode += formattedLine + "\n";
    }
    codeEditor.style.backgroundColor = "#f8f8f8";
    codeEditor.style.color = "#2d2d2d";
    codeEditor.innerHTML = formattedCode;
  });
  
// Read file and display code as table
inputFile.addEventListener('change', () => {
	const fileReader = new FileReader();
	fileReader.onload = () => {
		const code = fileReader.result;
		const codeRows = code.split('\n');
		codeTable.innerHTML = '<tr><th>Address</th><th>Code</th></tr>';
		codeRows.forEach((row, index) => {
			codeTable.innerHTML += `<tr><td>${index.toString(16).toUpperCase().padStart(4, '0')}</td><td>${row}</td></tr>`;
		});
	};
	fileReader.readAsText(inputFile.files[0]);
});